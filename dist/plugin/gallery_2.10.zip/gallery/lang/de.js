'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('gallery', 'de', {
        title: 'Galerie'
    });
})(CKEDITOR);
