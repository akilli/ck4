'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('grid', 'de', {
        title: 'Grid'
    });
})(CKEDITOR);
