# Grid Widget

This widgets just serves as a container for multiple instances of other widgets in order to apply certain styles on them, p.e. through flexbox or grid layout.

The resulting HTML will be

    <div class="grid">
        ...
    </div>

## Technical

This widget will only allow other widgets as child elements. The filtering now takes place on `downcast`.

## Demo

https://akilli.github.io/rte/ck4
