'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('section', 'de', {
        css: 'CSS-Klasse',
        info: 'Info',
        title: 'Section'
    });
})(CKEDITOR);
