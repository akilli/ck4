'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('section', 'en', {
        css: 'CSS class',
        info: 'Info',
        title: 'Section'
    });
})(CKEDITOR);
