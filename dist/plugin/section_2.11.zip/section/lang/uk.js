'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('section', 'uk', {
        css: 'CSS-клас',
        info: 'Інфо',
        title: 'Секція'
    });
})(CKEDITOR);
