# Details Widget

This widget handles details elements (`<details>` and `<summary>`). No configuration necessary.

## Example

You can see this plugin in action @ https://akilli.github.io/rte/ck4/
