'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('detail', 'en', {
        title: 'Details'
    });
})(CKEDITOR);
