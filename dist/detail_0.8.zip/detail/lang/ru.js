'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('detail', 'ru', {
        title: 'Спойлер'
    });
})(CKEDITOR);
