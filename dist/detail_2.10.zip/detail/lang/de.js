'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('detail', 'de', {
        title: 'Details'
    });
})(CKEDITOR);
