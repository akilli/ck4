# Details Widget

This widget provides support for *details* and *summary* elements. 

No configuration necessary.

## Demo

https://akilli.github.io/rte/ck4
